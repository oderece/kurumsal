<body id="page-top">
<nav class="navbar navbar-expand navbar-dark bg-dark static-top">

    <a class="navbar-brand mr-1" href="ayarlar.php">db Yönetim Paneli</a>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
        <div class="input-group">
            
            <div class="input-group-append">
                
            </div>
        </div>
    </form>

    <!-- Navbar -->

    <ul class="navbar-nav ml-auto ml-md-0">
        <li class="nav-item dropdown no-arrow mx-1">
            <a class="nav-link" target="_blank" href="../index.php" 
               aria-haspopup="true" aria-expanded="false">
               <span>Site Önizleme</span>
                <i class="fas fa-globe-europe"></i>
            </a>
        </li>
        <li class="nav-item dropdown no-arrow mx-1">
            <a class="nav-link" href="logout.php" 
               aria-haspopup="true" aria-expanded="false">
               <span>Çıkış Yap</span>
                <i class="fas fa-fw fa-sign-out-alt"></i>
            </a>
        </li>
    </ul>
</nav>