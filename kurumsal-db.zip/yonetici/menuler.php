<?php
include('../inc/ayar.php');
include('inc/head.php');
include('inc/nav.php');
include('inc/sidebar.php');

$sorgu = $baglanti->prepare("SELECT * FROM menuler");
$sorgu->execute();


?>

<div id="content-wrapper">

    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Menü Ayarları</li>
        </ol>
        

        <!-- DataTables Example -->
        <div class="card mb-3">

            <div class="card-body">


                <div class="table-responsive">
                    
                    <table class="table table-bordered" width="100%" cellspacing="0">
                        <thead>
                        <?php while ($sonuc = $sorgu->fetch()) { ?>

                            <tr><th>Menü 1</th><td><?= $sonuc["menu1"] ?></td></tr>
                            <tr><th>Menü 2</th><td><?= $sonuc["menu2"] ?></td></tr>
                            <tr><th>Menü 3</th><td><?= $sonuc["menu3"] ?></td></tr>
                            <tr><th>Menü 4</th><td><?= $sonuc["menu4"] ?></td></tr>
                            <tr><th>Menü 5</th><td><?= $sonuc["menu5"] ?></td></tr>
                            <tr><th>Menü 6</th><td><?= $sonuc["menu6"] ?></td></tr>
                            <tr><th>Menü 7</th><td><?= $sonuc["menu7"] ?></td></tr>
                            
                            
                            

                        
                        </thead>

                        <tbody>  
                            
                        </tbody>
                    </table><a class="btn btn-primary" href="menuguncelle.php?id=<?= $sonuc["id"] ?>">Menüleri Düzenle</a><?php
                        } //while bitimi
                        ?>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->
    <?php
    include('inc/footer.php');
    ?>
