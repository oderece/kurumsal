-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 08 Ağu 2020, 06:56:08
-- Sunucu sürümü: 5.7.26
-- PHP Sürümü: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `kurumsalsite`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ayarlar`
--

DROP TABLE IF EXISTS `ayarlar`;
CREATE TABLE IF NOT EXISTS `ayarlar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteadi` varchar(225) NOT NULL,
  `sitelogo` varchar(225) NOT NULL,
  `sitedesc` varchar(225) NOT NULL,
  `sitekeyw` varchar(225) NOT NULL,
  `face` varchar(225) NOT NULL,
  `insta` varchar(225) NOT NULL,
  `twit` varchar(225) NOT NULL,
  `eposta` varchar(225) NOT NULL,
  `adres` varchar(225) NOT NULL,
  `harita` text NOT NULL,
  `tel` varchar(225) NOT NULL,
  `copy` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `ayarlar`
--

INSERT INTO `ayarlar` (`id`, `siteadi`, `sitelogo`, `sitedesc`, `sitekeyw`, `face`, `insta`, `twit`, `eposta`, `adres`, `harita`, `tel`, `copy`) VALUES
(1, 'Site Adı', 'Site Logosu', 'Site Açıklaması', 'site,keywords,anahtar,kelimeler', 'https://www.facebook.com/dgknbzglu1907', 'https://www.instagram.com/dgknbzglumedia', 'https://www.twitter.com/dgknbzglu', 'info@info.com', 'Örnek mahallesi Örnek sokak A10/13', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3011.713890636326!2d29.03463461478263!3d40.9877454286381!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14cab870784d1389%3A0x2bf4921764859e70!2zRmVuZXJiYWjDp2UgxZ7DvGtyw7wgU2FyYcOnb8SfbHUgU3RhZHl1bXU!5e0!3m2!1str!2str!4v1596811779999!5m2!1str!2str', '0123 456 78 99', 'dgknbzglu');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `blog`
--

DROP TABLE IF EXISTS `blog`;
CREATE TABLE IF NOT EXISTS `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resim` char(100) NOT NULL,
  `baslik` text NOT NULL,
  `aciklama` text NOT NULL,
  `tarih` date NOT NULL,
  `buton` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `blog`
--

INSERT INTO `blog` (`id`, `resim`, `baslik`, `aciklama`, `tarih`, `buton`) VALUES
(1, 'blog_1.jpg', 'Blog Başlığı', 'Açıklamamız', '2020-08-03', 'Devamını Oku'),
(2, 'blog_3.jpg', 'Blog Başlığı', 'Açıklamamız', '2020-08-05', 'Devamını Oku'),
(3, 'blog_2.jpg', 'Blog Başlığı', 'Açıklamamız', '2020-08-08', 'Devamını Oku');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hakkimizda`
--

DROP TABLE IF EXISTS `hakkimizda`;
CREATE TABLE IF NOT EXISTS `hakkimizda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hak1` text NOT NULL,
  `hak2` text NOT NULL,
  `hakres` char(75) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `hakkimizda`
--

INSERT INTO `hakkimizda` (`id`, `hak1`, `hak2`, `hakres`) VALUES
(1, 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500\'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır. 1960\'larda Lorem Ipsum pasajları da içeren Letraset yapraklarının yayınlanması ile ve yakın zamanda Aldus PageMaker gibi Lorem Ipsum sürümleri içeren masaüstü yayıncılık yazılımları ile popüler olmuştur.', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500\'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır. 1960\'larda Lorem Ipsum pasajları da içeren Letraset yapraklarının yayınlanması ile ve yakın zamanda Aldus PageMaker gibi Lorem Ipsum sürümleri içeren masaüstü yayıncılık yazılımları ile popüler olmuştur.', 'about.jpg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanicilar`
--

DROP TABLE IF EXISTS `kullanicilar`;
CREATE TABLE IF NOT EXISTS `kullanicilar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kadi` varchar(50) NOT NULL,
  `parola` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `kullanicilar`
--

INSERT INTO `kullanicilar` (`id`, `kadi`, `parola`) VALUES
(1, 'demo', '31411f16e675560d45d82d1033d6a897');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `menuler`
--

DROP TABLE IF EXISTS `menuler`;
CREATE TABLE IF NOT EXISTS `menuler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu1` varchar(225) NOT NULL,
  `menu2` varchar(225) NOT NULL,
  `menu3` varchar(225) NOT NULL,
  `menu4` varchar(225) NOT NULL,
  `menu5` varchar(225) NOT NULL,
  `menu6` varchar(225) NOT NULL,
  `menu7` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `menuler`
--

INSERT INTO `menuler` (`id`, `menu1`, `menu2`, `menu3`, `menu4`, `menu5`, `menu6`, `menu7`) VALUES
(1, 'Ana Sayfa', 'Hakkımızda', 'Servisler', 'Projeler', 'Blog', 'İletişim', 'Panel');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `musteri`
--

DROP TABLE IF EXISTS `musteri`;
CREATE TABLE IF NOT EXISTS `musteri` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `yorum` text NOT NULL,
  `yazar` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `musteri`
--

INSERT INTO `musteri` (`id`, `yorum`, `yazar`) VALUES
(1, 'Lorem ipsum', 'Ahmet Mehmet'),
(2, 'Lorem ipsum 2', 'Fatma Ceylan'),
(3, 'Lorem ipsum 3', 'Hatice Yüksek'),
(4, 'Lorem ipsum 4', 'Ferhat Babacan');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `projeler`
--

DROP TABLE IF EXISTS `projeler`;
CREATE TABLE IF NOT EXISTS `projeler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pr` char(225) NOT NULL,
  `alt` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `projeler`
--

INSERT INTO `projeler` (`id`, `pr`, `alt`) VALUES
(9, 'person_4.jpg', 'Erkek 2'),
(8, 'person_7.jpg', 'Kadın 2'),
(7, 'person_2.jpg', 'Erkek 1');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `servisler`
--

DROP TABLE IF EXISTS `servisler`;
CREATE TABLE IF NOT EXISTS `servisler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `baslik` varchar(225) NOT NULL,
  `aciklama` varchar(225) NOT NULL,
  `resim` char(75) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `servisler`
--

INSERT INTO `servisler` (`id`, `baslik`, `aciklama`, `resim`) VALUES
(1, 'Servis 1', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. ', '001-travel.svg'),
(2, 'Servis 2', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir.', '002-travel-1.svg'),
(3, 'Servis 3', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir.', '003-travel-2.svg'),
(4, 'Servis 4', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir.', '004-travel-3.svg'),
(5, 'Servis 5', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir.', '005-travel-4.svg'),
(6, 'Servis 6', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir.', '006-food.svg');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `slider`
--

DROP TABLE IF EXISTS `slider`;
CREATE TABLE IF NOT EXISTS `slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sliderbaslik` varchar(225) NOT NULL,
  `slideraciklama` varchar(225) NOT NULL,
  `sliderfoto` char(100) NOT NULL,
  `sliderbuton` varchar(225) NOT NULL,
  `sliderlink` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `slider`
--

INSERT INTO `slider` (`id`, `sliderbaslik`, `slideraciklama`, `sliderfoto`, `sliderbuton`, `sliderlink`) VALUES
(1, 'PHP PDO Admin Paneli', 'PDO ile MySQL admin paneli yönetme', 'wallpaperflare.png', 'Daha Fazla Bilgi', 'https://www.dgknbzglu.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
